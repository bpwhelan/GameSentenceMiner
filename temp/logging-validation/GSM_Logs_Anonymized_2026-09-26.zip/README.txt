GameSentenceMiner logs

backend.log       Python backend and helper diagnostics, including errors.
ocr.log           Persistent OCR diagnostics, including OCR inside the backend.
desktop.log       Desktop app, updates, and embedded overlay diagnostics.
process-output.log  Raw managed process output and startup failures.
ocr-debug.jsonl    Optional advanced OCR traces, with timestamps and process IDs.
anki-timing.log   Optional Anki card timing diagnostics (development builds).
history/          Rotated logs and consolidated logs from older GSM versions.
.locks/           Internal file locks. These are not logs and are not exported.

Files append across restarts. Each active log is limited to 5 MiB with up to
five backups in history/. History older than seven days is removed on startup.
Legacy logs are consolidated by component, keeping up to three 5 MiB files each.
Empty error files are removed; errors stay with their component's diagnostics.
Process IDs are recorded inside logs instead of creating a new file per launch.

Use Export Logs in GSM to include current logs, OCR debug traces, and history.
The export redacts copies; local logs can contain private paths and game text.
